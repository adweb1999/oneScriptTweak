//
//  ESP.h
//  oneScriptTweak - ESP Module
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface OSESPEngine : NSObject

+ (instancetype)sharedEngine;

// ESP Configuration
@property (nonatomic, assign) BOOL enabled;
@property (nonatomic, assign) BOOL showBoxes;
@property (nonatomic, assign) BOOL showSnaplines;
@property (nonatomic, assign) BOOL showSkeleton;
@property (nonatomic, assign) BOOL showNames;
@property (nonatomic, assign) BOOL showDistance;
@property (nonatomic, assign) BOOL showHealth;
@property (nonatomic, assign) float maxDistance;

// Colors
@property (nonatomic, strong) UIColor *enemyColor;
@property (nonatomic, strong) UIColor *teamColor;
@property (nonatomic, strong) UIColor *npcColor;
@property (nonatomic, strong) UIColor *vehicleColor;

// Drawing
- (void)drawESPOnView:(UIView *)gameView;
- (void)drawBox:(CGRect)rect color:(UIColor *)color view:(UIView *)view;
- (void)drawSnapline:(CGPoint)from to:(CGPoint)to color:(UIColor *)color view:(UIView *)view;
- (void)drawSkeleton:(NSArray *)bones color:(UIColor *)color view:(UIView *)view;
- (void)drawText:(NSString *)text at:(CGPoint)point color:(UIColor *)color view:(UIView *)view;

// Entity detection (override for specific game)
- (NSArray *)getEntities;
- (CGPoint)worldToScreen:(CGVector)worldPos view:(UIView *)view;

@end

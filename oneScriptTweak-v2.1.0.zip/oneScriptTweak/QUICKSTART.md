# 🚀 Quick Start Guide (Windows Users)

## الطريقة السريعة للحصول على dylib جاهز

### الخطوة 1: إنشاء مستودع GitHub
1. اذهب إلى https://github.com/new
2. اسم المستودع: `oneScriptTweak`
3. اجعله `Public` أو `Private`
4. انقر `Create repository`

### الخطوة 2: رفع الملفات
```bash
# على Windows، استخدم GitHub Desktop أو Git Bash
cd oneScriptTweak
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/oneScriptTweak.git
git push -u origin main
```

### الخطوة 3: تفعيل البناء
1. اذهب إلى `Actions` tab في المستودع
2. انقر على `I understand my workflows, go ahead and enable them`
3. اذهب إلى `Actions > Build oneScript Tweak`
4. انقر `Run workflow` > `Run workflow`

### الخطوة 4: تحميل dylib
1. انتظر 5-10 دقائق
2. اذهب إلى `Actions` tab
3. انقر على آخر workflow
4. انقر `Artifacts` > `oneScript-deb-package`
5. سيُنزّل ملف `.deb` يحتوي على dylib جاهز!

---

## 📦 محتويات ملف DEB

بعد فك الضغط عن `.deb` (استخدام 7-Zip):
```
oneScriptTweak.deb/
├── DEBIAN/
│   └── control
└── Library/
    └── MobileSubstrate/
        └── DynamicLibraries/
            ├── oneScriptTweak.dylib    ← هذا الملف المطلوب!
            └── oneScriptTweak.plist
```

---

## 🔧 التثبيت على iOS (Jailbreak)

### الطريقة 1: Filza
1. انقل `.deb` إلى iPhone
2. افتح Filza
3. انقر على `.deb` > `Install`
4. Respring

### الطريقة 2: Sileo/Cydia
1. أضف مصدر: `https://your-repo.com`
2. ابحث عن `oneScriptTweak`
3. انقر `Install`

### الطريقة 3: SSH
```bash
scp oneScriptTweak.deb root@192.168.1.100:/tmp/
ssh root@192.168.1.100
dpkg -i /tmp/oneScriptTweak.deb
killall -9 SpringBoard
```

---

## 🎮 الاستخدام

| إيماءة | الوظيفة |
|--------|---------|
| نقر مزدوج بـ 3 أصابع | إظهار/إخفاء القائمة |
| سحب القائمة | نقلها |
| نقر خارج القائمة | إغلاقها |

---

## ⚠️ ملاحظة مهمة

**يجب تعديل Bundle ID قبل البناء!**

افتح `Tweak.xm` وابحث عن:
```objc
static NSString * const kBundleFilter = @"com.yourgame.bundle";
```

غيره إلى Bundle ID للعبة المستهدفة، مثلاً:
```objc
static NSString * const kBundleFilter = @"com.pubg.newstate";
```

---

## 🆘 الدعم

إذا واجهت مشاكل:
1. افتح `Issues` في المستودع
2. أو تواصل على Telegram: @oneScriptSupport

**Built with ❤️ by oneScript Team**

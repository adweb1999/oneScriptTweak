//
//  Utils.mm
//  oneScriptTweak - Utility Implementation
//

#import "Utils.h"
#import <substrate.h>
#import <sys/sysctl.h>
#import <sys/types.h>
#import <mach/mach.h>
#import <mach-o/dyld.h>

@implementation OSUtils

#pragma mark - Memory Utilities

+ (void)writeMemory:(uintptr_t)address value:(uint32_t)value {
    vm_write(mach_task_self(), address, (vm_offset_t)&value, sizeof(value));
}

+ (uint32_t)readMemory:(uintptr_t)address {
    uint32_t value = 0;
    vm_read_overwrite(mach_task_self(), address, sizeof(value), (vm_address_t)&value, NULL);
    return value;
}

+ (void)writeFloat:(uintptr_t)address value:(float)value {
    vm_write(mach_task_self(), address, (vm_offset_t)&value, sizeof(value));
}

+ (float)readFloat:(uintptr_t)address {
    float value = 0;
    vm_read_overwrite(mach_task_self(), address, sizeof(value), (vm_address_t)&value, NULL);
    return value;
}

+ (void)writeBytes:(uintptr_t)address bytes:(const void *)bytes length:(size_t)length {
    // Make memory writable
    kern_return_t err = vm_protect(mach_task_self(), address, length, false, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
    if (err == KERN_SUCCESS) {
        memcpy((void *)address, bytes, length);
        vm_protect(mach_task_self(), address, length, false, VM_PROT_READ | VM_PROT_EXECUTE);
    }
}

#pragma mark - Hook Utilities

+ (void)hookFunction:(void *)target with:(void *)replacement original:(void **)original {
    MSHookFunction(target, replacement, original);
}

+ (void)hookMessage:(Class)cls selector:(SEL)sel imp:(IMP)imp {
    Method method = class_getInstanceMethod(cls, sel);
    if (method) {
        method_setImplementation(method, imp);
    }
}

#pragma mark - Math Utilities

+ (float)distanceFrom:(CGPoint)a to:(CGPoint)b {
    return hypot(b.x - a.x, b.y - a.y);
}

+ (float)angleFrom:(CGPoint)a to:(CGPoint)b {
    return atan2(b.y - a.y, b.x - a.x);
}

+ (CGPoint)lerpFrom:(CGPoint)a to:(CGPoint)b factor:(float)t {
    return CGPointMake(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
}

#pragma mark - Drawing Utilities

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    [color setFill];
    UIRectFill(CGRectMake(0, 0, size.width, size.height));
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (void)addGlowToView:(UIView *)view color:(UIColor *)color radius:(CGFloat)radius {
    view.layer.shadowColor = color.CGColor;
    view.layer.shadowRadius = radius;
    view.layer.shadowOpacity = 0.8;
    view.layer.shadowOffset = CGSizeZero;
}

#pragma mark - Device Info

+ (NSString *)deviceModel {
    struct utsname systemInfo;
    uname(&systemInfo);
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}

+ (NSString *)iosVersion {
    return [[UIDevice currentDevice] systemVersion];
}

+ (BOOL)isJailbroken {
    // Check for common jailbreak files
    NSArray *paths = @[@"/Applications/Cydia.app",
                       @"/Library/MobileSubstrate/MobileSubstrate.dylib",
                       @"/bin/bash",
                       @"/usr/sbin/sshd",
                       @"/etc/apt"];
    for (NSString *path in paths) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:path]) return YES;
    }
    return NO;
}

+ (BOOL)isDebuggerAttached {
    struct kinfo_proc info;
    size_t info_size = sizeof(info);
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };

    if (sysctl(mib, 4, &info, &info_size, NULL, 0) == -1) return NO;
    return (info.kp_proc.p_flag & P_TRACED) != 0;
}

@end

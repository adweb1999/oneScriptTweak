//
//  MenuView.h
//  oneScriptTweak
//

#import <UIKit/UIKit.h>

// ====== COLOR THEME ======
#define OS_BG_MAIN      [UIColor colorWithRed:0.071 green:0.067 blue:0.102 alpha:1.0]
#define OS_BG_PANEL     [UIColor colorWithRed:0.102 green:0.098 blue:0.145 alpha:1.0]
#define OS_BG_CARD      [UIColor colorWithRed:0.129 green:0.122 blue:0.180 alpha:1.0]
#define OS_BG_ITEM      [UIColor colorWithRed:0.165 green:0.153 blue:0.251 alpha:1.0]
#define OS_BG_ACTIVE    [UIColor colorWithRed:0.180 green:0.169 blue:0.271 alpha:1.0]
#define OS_BG_BTN       [UIColor colorWithRed:0.192 green:0.180 blue:0.290 alpha:1.0]
#define OS_PURPLE       [UIColor colorWithRed:0.486 green:0.416 blue:0.961 alpha:1.0]
#define OS_PURPLE_DIM   [UIColor colorWithRed:0.239 green:0.220 blue:0.376 alpha:1.0]
#define OS_TEXT1        [UIColor whiteColor]
#define OS_TEXT2        [UIColor colorWithRed:0.690 green:0.682 blue:0.784 alpha:1.0]
#define OS_TEXT3        [UIColor colorWithRed:0.420 green:0.408 blue:0.522 alpha:1.0]
#define OS_ORANGE       [UIColor colorWithRed:0.961 green:0.651 blue:0.137 alpha:1.0]
#define OS_GREEN        [UIColor colorWithRed:0.290 green:0.871 blue:0.502 alpha:1.0]
#define OS_RED          [UIColor colorWithRed:0.973 green:0.443 blue:0.443 alpha:1.0]
#define OS_BORDER       [UIColor colorWithRed:0.165 green:0.157 blue:0.251 alpha:1.0]

// ====== APP STATE ======
@interface OSAppState : NSObject
+ (instancetype)sharedState;

// Visuals
@property (nonatomic, assign) BOOL espEnabled;
@property (nonatomic, assign) BOOL espBoxes;
@property (nonatomic, assign) BOOL espSnaplines;
@property (nonatomic, assign) BOOL espSkeleton;
@property (nonatomic, assign) BOOL espCount;
@property (nonatomic, assign) BOOL espAdvanced;
@property (nonatomic, assign) double espRadius;
@property (nonatomic, assign) BOOL espNames;
@property (nonatomic, assign) BOOL showPlayers;
@property (nonatomic, assign) BOOL showVehicles;
@property (nonatomic, assign) BOOL showNPCs;
@property (nonatomic, assign) BOOL showMarkers;

// Aimbot
@property (nonatomic, assign) BOOL aimbotEnabled;
@property (nonatomic, copy) NSString *aimType;
@property (nonatomic, copy) NSString *aimBone;
@property (nonatomic, assign) double aimFOV;
@property (nonatomic, assign) double aimSmooth;
@property (nonatomic, assign) BOOL showAimFOV;
@property (nonatomic, assign) BOOL visibilityCheck;
@property (nonatomic, assign) BOOL aimAdvanced;
@property (nonatomic, assign) double aimRadius;

// Player
@property (nonatomic, assign) BOOL crosshair;
@property (nonatomic, assign) BOOL unlimitedStamina;
@property (nonatomic, assign) BOOL playerMod;
@property (nonatomic, assign) BOOL fovChanger;
@property (nonatomic, assign) double fovValue;
@property (nonatomic, assign) BOOL speedHack;
@property (nonatomic, assign) double speedValue;
@property (nonatomic, assign) BOOL vehicleSpeed;
@property (nonatomic, assign) BOOL flyHack;
@property (nonatomic, copy) NSString *selectedSkin;
@property (nonatomic, copy) NSString *selectedClothes;

// Settings
@property (nonatomic, assign) BOOL streamerMode;
@property (nonatomic, assign) BOOL deactivateCheat;
@property (nonatomic, assign) double targetFPS;
@property (nonatomic, copy) NSString *tillText;

- (void)deactivateAll;
@end

// ====== MENU VIEW ======
@interface OSMenuView : UIView
@property (nonatomic, strong) UIView *menuContainer;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) NSString *currentTab;
@property (nonatomic, strong) NSString *currentSubTab;
@property (nonatomic, strong) NSMutableArray *tabButtons;
@property (nonatomic, strong) NSMutableArray *subTabButtons;

- (void)showMenu;
- (void)hideMenu;
- (void)handlePan:(UIPanGestureRecognizer *)gesture;
- (void)switchToTab:(NSString *)tab;
- (void)switchToSubTab:(NSString *)subTab;
@end

// ====== UI COMPONENTS ======
@interface OSToggle : UIView
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UISwitch *toggle;
@property (nonatomic, copy) void (^onToggle)(BOOL isOn);
- (instancetype)initWithLabel:(NSString *)label state:(BOOL)state;
@end

@interface OSSliderView : UIView
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, strong) UILabel *valueLabel;
@property (nonatomic, copy) void (^onChange)(double value);
- (instancetype)initWithLabel:(NSString *)label value:(double)value min:(double)min max:(double)max;
@end

@interface OSCheckbox : UIView
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UIView *box;
@property (nonatomic, assign) BOOL isChecked;
@property (nonatomic, copy) void (^onToggle)(BOOL isChecked);
- (instancetype)initWithLabel:(NSString *)label checked:(BOOL)checked;
@end

@interface OSDropdown : UIView
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) NSArray *options;
@property (nonatomic, copy) NSString *selected;
@property (nonatomic, copy) void (^onChange)(NSString *value);
- (instancetype)initWithLabel:(NSString *)label options:(NSArray *)options selected:(NSString *)selected;
@end

@interface OSStatusBadge : UIView
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UIView *dot;
- (instancetype)initWithActive:(BOOL)active activeText:(NSString *)activeText inactiveText:(NSString *)inactiveText;
- (void)setActive:(BOOL)active;
@end

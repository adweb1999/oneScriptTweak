//
//  MenuView.mm
//  oneScriptTweak - Full UI Implementation
//

#import "MenuView.h"
#import <objc/runtime.h>

// ====== APP STATE IMPLEMENTATION ======
@implementation OSAppState

+ (instancetype)sharedState {
    static OSAppState *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        // Visuals defaults
        _espEnabled = NO;
        _espBoxes = NO;
        _espSnaplines = NO;
        _espSkeleton = NO;
        _espCount = NO;
        _espAdvanced = YES;
        _espRadius = 279;
        _espNames = YES;
        _showPlayers = YES;
        _showVehicles = YES;
        _showNPCs = NO;
        _showMarkers = NO;

        // Aimbot defaults
        _aimbotEnabled = NO;
        _aimType = @"Aim Lock";
        _aimBone = @"Body";
        _aimFOV = 51;
        _aimSmooth = 25;
        _showAimFOV = NO;
        _visibilityCheck = YES;
        _aimAdvanced = YES;
        _aimRadius = 5000;

        // Player defaults
        _crosshair = NO;
        _unlimitedStamina = NO;
        _playerMod = NO;
        _fovChanger = NO;
        _fovValue = 90;
        _speedHack = NO;
        _speedValue = 1.5;
        _vehicleSpeed = NO;
        _flyHack = NO;
        _selectedSkin = @"ManJohn";
        _selectedClothes = @"ManJohn";

        // Settings defaults
        _streamerMode = NO;
        _deactivateCheat = NO;
        _targetFPS = 60;
        _tillText = @"18d 22h 37m";

        // Start countdown timer
        [self startTimer];
    }
    return self;
}

- (void)startTimer {
    __block int totalSeconds = 18 * 86400 + 22 * 3600 + 37 * 60;
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(timer, DISPATCH_TIME_NOW, 60 * NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(timer, ^{
        if (totalSeconds > 0) {
            totalSeconds -= 60;
            int d = totalSeconds / 86400;
            int h = (totalSeconds % 86400) / 3600;
            int m = (totalSeconds % 3600) / 60;
            self.tillText = [NSString stringWithFormat:@"%dd %dh %dm", d, h, m];
        }
    });
    dispatch_resume(timer);
}

- (void)deactivateAll {
    self.espEnabled = NO;
    self.aimbotEnabled = NO;
    self.crosshair = NO;
    self.unlimitedStamina = NO;
    self.flyHack = NO;
    self.speedHack = NO;
    self.playerMod = NO;
    self.vehicleSpeed = NO;
    self.fovChanger = NO;
}

@end

// ====== MENU VIEW IMPLEMENTATION ======
@implementation OSMenuView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        _currentTab = @"Visuals";
        _currentSubTab = @"General";
        _tabButtons = [NSMutableArray array];
        _subTabButtons = [NSMutableArray array];
        [self setupMenu];
    }
    return self;
}

- (void)setupMenu {
    // Semi-transparent backdrop
    UIView *backdrop = [[UIView alloc] initWithFrame:self.bounds];
    backdrop.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
    backdrop.tag = 999;
    [self addSubview:backdrop];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideMenu)];
    [backdrop addGestureRecognizer:tap];

    // Main container - Dark glassmorphism style
    _menuContainer = [[UIView alloc] initWithFrame:CGRectMake(20, 60, 340, self.bounds.size.height - 120)];
    _menuContainer.backgroundColor = [UIColor colorWithRed:0.102 green:0.098 blue:0.145 alpha:0.97];
    _menuContainer.layer.cornerRadius = 20;
    _menuContainer.layer.borderWidth = 1;
    _menuContainer.layer.borderColor = [UIColor colorWithRed:0.165 green:0.157 blue:0.251 alpha:0.5].CGColor;
    _menuContainer.clipsToBounds = YES;

    // Add subtle shadow
    _menuContainer.layer.shadowColor = [UIColor blackColor].CGColor;
    _menuContainer.layer.shadowOffset = CGSizeMake(0, 10);
    _menuContainer.layer.shadowRadius = 30;
    _menuContainer.layer.shadowOpacity = 0.5;

    [self addSubview:_menuContainer];

    // ====== HEADER ======
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 340, 70)];
    header.backgroundColor = [UIColor colorWithRed:0.071 green:0.067 blue:0.102 alpha:0.8];

    // Logo
    UILabel *logo = [[UILabel alloc] initWithFrame:CGRectMake(20, 15, 150, 25)];
    logo.text = @"oneScript";
    logo.font = [UIFont systemFontOfSize:22 weight:UIFontWeightLight];
    logo.textColor = [UIColor whiteColor];
    [header addSubview:logo];

    // Version badge
    UILabel *versionBadge = [[UILabel alloc] initWithFrame:CGRectMake(270, 20, 50, 18)];
    versionBadge.text = @"v2.1";
    versionBadge.font = [UIFont systemFontOfSize:10 weight:UIFontWeightMedium];
    versionBadge.textColor = OS_TEXT3;
    versionBadge.textAlignment = NSTextAlignmentRight;
    [header addSubview:versionBadge];

    // User info
    UILabel *userLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 42, 200, 16)];
    userLabel.font = [UIFont systemFontOfSize:12];
    userLabel.textColor = OS_TEXT3;
    OSAppState *state = [OSAppState sharedState];
    userLabel.text = state.streamerMode ? @"••••••" : @"hilal  |  Standard";
    [header addSubview:userLabel];

    // Expiry
    UILabel *expiryLabel = [[UILabel alloc] initWithFrame:CGRectMake(240, 42, 80, 16)];
    expiryLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
    expiryLabel.textColor = OS_ORANGE;
    expiryLabel.textAlignment = NSTextAlignmentRight;
    expiryLabel.text = state.streamerMode ? @"••••••••" : state.tillText;
    [header addSubview:expiryLabel];

    [_menuContainer addSubview:header];

    // ====== TAB BAR ======
    UIView *tabBar = [[UIView alloc] initWithFrame:CGRectMake(0, 70, 340, 44)];
    tabBar.backgroundColor = [UIColor colorWithRed:0.129 green:0.122 blue:0.180 alpha:0.6];

    NSArray *tabs = @[@"Visuals", @"Aimbot", @"Player", @"Teleport", @"Settings"];
    CGFloat tabWidth = 340.0 / tabs.count;

    for (int i = 0; i < tabs.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(i * tabWidth, 0, tabWidth, 44);
        [btn setTitle:tabs[i] forState:UIControlStateNormal];
        [btn setTitleColor:OS_TEXT3 forState:UIControlStateNormal];
        [btn setTitleColor:OS_TEXT1 forState:UIControlStateSelected];
        btn.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        btn.tag = i;
        [btn addTarget:self action:@selector(tabTapped:) forControlEvents:UIControlEventTouchUpInside];

        if ([tabs[i] isEqualToString:_currentTab]) {
            btn.selected = YES;
            btn.backgroundColor = OS_BG_ACTIVE;
        }

        [_tabButtons addObject:btn];
        [tabBar addSubview:btn];
    }

    // Active indicator line
    UIView *indicator = [[UIView alloc] initWithFrame:CGRectMake(0, 42, tabWidth, 2)];
    indicator.backgroundColor = OS_PURPLE;
    indicator.tag = 100;
    [tabBar addSubview:indicator];

    [_menuContainer addSubview:tabBar];

    // ====== SUB TAB BAR ======
    UIView *subTabBar = [[UIView alloc] initWithFrame:CGRectMake(0, 114, 340, 36)];
    subTabBar.backgroundColor = [UIColor clearColor];
    subTabBar.tag = 200;
    [_menuContainer addSubview:subTabBar];

    // ====== SCROLL CONTENT ======
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 150, 340, _menuContainer.bounds.size.height - 150)];
    _scrollView.backgroundColor = [UIColor clearColor];
    _scrollView.showsVerticalScrollIndicator = YES;
    _scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    [_menuContainer addSubview:_scrollView];

    _contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 340, 800)];
    _contentView.backgroundColor = [UIColor clearColor];
    [_scrollView addSubview:_contentView];

    // Initial content
    [self refreshContent];
}

- (void)tabTapped:(UIButton *)sender {
    NSArray *tabs = @[@"Visuals", @"Aimbot", @"Player", @"Teleport", @"Settings"];
    NSString *tab = tabs[sender.tag];
    [self switchToTab:tab];
}

- (void)switchToTab:(NSString *)tab {
    _currentTab = tab;

    // Update tab buttons
    for (UIButton *btn in _tabButtons) {
        btn.selected = NO;
        btn.backgroundColor = [UIColor clearColor];
    }

    NSInteger idx = [@{@"Visuals":@0, @"Aimbot":@1, @"Player":@2, @"Teleport":@3, @"Settings":@4} objectForKey:tab] ? 
                    [[@{@"Visuals":@0, @"Aimbot":@1, @"Player":@2, @"Teleport":@3, @"Settings":@4} objectForKey:tab] integerValue] : 0;

    UIButton *activeBtn = _tabButtons[idx];
    activeBtn.selected = YES;
    activeBtn.backgroundColor = OS_BG_ACTIVE;

    // Move indicator
    UIView *indicator = [_menuContainer viewWithTag:100];
    CGFloat tabWidth = 340.0 / 5;
    [UIView animateWithDuration:0.2 animations:^{
        indicator.frame = CGRectMake(idx * tabWidth, 42, tabWidth, 2);
    }];

    // Reset sub tab
    _currentSubTab = @"General";
    [self refreshContent];
}

- (void)switchToSubTab:(NSString *)subTab {
    _currentSubTab = subTab;
    [self refreshContent];
}

- (void)refreshContent {
    // Clear content
    for (UIView *v in _contentView.subviews) {
        [v removeFromSuperview];
    }

    // Clear sub tabs
    UIView *subTabBar = [_menuContainer viewWithTag:200];
    for (UIView *v in subTabBar.subviews) {
        [v removeFromSuperview];
    }

    CGFloat y = 0;
    OSAppState *state = [OSAppState sharedState];

    // ====== VISUALS TAB ======
    if ([_currentTab isEqualToString:@"Visuals"]) {
        NSArray *subTabs = @[@"General", @"Advanced", @"Filter"];
        [self setupSubTabs:subTabs y:0];
        y = 50;

        if ([_currentSubTab isEqualToString:@"General"]) {
            // Status badge
            OSStatusBadge *badge = [[OSStatusBadge alloc] initWithActive:state.espEnabled activeText:@"ESP ACTIVE" inactiveText:@"ESP OFF"];
            badge.frame = CGRectMake(16, y, 140, 32);
            [_contentView addSubview:badge];
            y += 44;

            // Enable ESP
            OSToggle *espToggle = [[OSToggle alloc] initWithLabel:@"Enable ESP" state:state.espEnabled];
            espToggle.frame = CGRectMake(16, y, 308, 44);
            espToggle.onToggle = ^(BOOL isOn) {
                state.espEnabled = isOn;
                [badge setActive:isOn];
                [self showToast:isOn ? @"✓ ESP Enabled" : @"ESP Disabled"];
            };
            [_contentView addSubview:espToggle];
            y += 50;

            // 2-column grid
            UIView *grid = [[UIView alloc] initWithFrame:CGRectMake(16, y, 308, 100)];

            OSToggle *boxToggle = [[OSToggle alloc] initWithLabel:@"ESP Boxes" state:state.espBoxes];
            boxToggle.frame = CGRectMake(0, 0, 150, 44);
            boxToggle.onToggle = ^(BOOL isOn) { state.espBoxes = isOn; [self showToast:[NSString stringWithFormat:@"ESP Boxes: %@", isOn ? @"ON" : @"OFF"]]; };
            [grid addSubview:boxToggle];

            OSToggle *snapToggle = [[OSToggle alloc] initWithLabel:@"ESP Snaplines" state:state.espSnaplines];
            snapToggle.frame = CGRectMake(158, 0, 150, 44);
            snapToggle.onToggle = ^(BOOL isOn) { state.espSnaplines = isOn; [self showToast:[NSString stringWithFormat:@"ESP Snaplines: %@", isOn ? @"ON" : @"OFF"]]; };
            [grid addSubview:snapToggle];

            OSToggle *skelToggle = [[OSToggle alloc] initWithLabel:@"ESP Skeleton" state:state.espSkeleton];
            skelToggle.frame = CGRectMake(0, 50, 150, 44);
            skelToggle.onToggle = ^(BOOL isOn) { state.espSkeleton = isOn; [self showToast:[NSString stringWithFormat:@"ESP Skeleton: %@", isOn ? @"ON" : @"OFF"]]; };
            [grid addSubview:skelToggle];

            OSToggle *countToggle = [[OSToggle alloc] initWithLabel:@"ESP Count" state:state.espCount];
            countToggle.frame = CGRectMake(158, 50, 150, 44);
            countToggle.onToggle = ^(BOOL isOn) { state.espCount = isOn; [self showToast:[NSString stringWithFormat:@"ESP Count: %@", isOn ? @"ON" : @"OFF"]]; };
            [grid addSubview:countToggle];

            [_contentView addSubview:grid];
            y += 110;

        } else if ([_currentSubTab isEqualToString:@"Advanced"]) {
            OSToggle *advToggle = [[OSToggle alloc] initWithLabel:@"ESP Advanced" state:state.espAdvanced];
            advToggle.frame = CGRectMake(16, y, 308, 44);
            advToggle.onToggle = ^(BOOL isOn) { state.espAdvanced = isOn; };
            [_contentView addSubview:advToggle];
            y += 50;

            OSSliderView *radiusSlider = [[OSSliderView alloc] initWithLabel:@"ESP Radius" value:state.espRadius min:50 max:1000];
            radiusSlider.frame = CGRectMake(16, y, 308, 60);
            radiusSlider.onChange = ^(double value) { state.espRadius = value; };
            [_contentView addSubview:radiusSlider];
            y += 66;

            OSToggle *namesToggle = [[OSToggle alloc] initWithLabel:@"ESP Names" state:state.espNames];
            namesToggle.frame = CGRectMake(16, y, 308, 44);
            namesToggle.onToggle = ^(BOOL isOn) { state.espNames = isOn; };
            [_contentView addSubview:namesToggle];
            y += 50;

        } else { // Filter
            NSArray *filters = @[@"Show Players", @"Show Vehicles", @"Show NPCs", @"Show Markers"];
            NSArray *states = @[@(state.showPlayers), @(state.showVehicles), @(state.showNPCs), @(state.showMarkers)];

            for (int i = 0; i < filters.count; i++) {
                OSToggle *toggle = [[OSToggle alloc] initWithLabel:filters[i] state:[states[i] boolValue]];
                toggle.frame = CGRectMake(16, y, 308, 44);
                toggle.onToggle = ^(BOOL isOn) {
                    if (i == 0) state.showPlayers = isOn;
                    else if (i == 1) state.showVehicles = isOn;
                    else if (i == 2) state.showNPCs = isOn;
                    else state.showMarkers = isOn;
                };
                [_contentView addSubview:toggle];
                y += 50;
            }
        }
    }

    // ====== AIMBOT TAB ======
    else if ([_currentTab isEqualToString:@"Aimbot"]) {
        NSArray *subTabs = @[@"General", @"Advanced"];
        [self setupSubTabs:subTabs y:0];
        y = 50;

        if ([_currentSubTab isEqualToString:@"General"]) {
            OSStatusBadge *badge = [[OSStatusBadge alloc] initWithActive:state.aimbotEnabled activeText:@"Aimbot ACTIVE" inactiveText:@"Aimbot OFF"];
            badge.frame = CGRectMake(16, y, 160, 32);
            [_contentView addSubview:badge];
            y += 44;

            OSToggle *aimToggle = [[OSToggle alloc] initWithLabel:@"Enable Aimbot" state:state.aimbotEnabled];
            aimToggle.frame = CGRectMake(16, y, 308, 44);
            aimToggle.onToggle = ^(BOOL isOn) {
                state.aimbotEnabled = isOn;
                [badge setActive:isOn];
                [self showToast:isOn ? @"✓ Aimbot Enabled" : @"Aimbot Disabled"];
            };
            [_contentView addSubview:aimToggle];
            y += 50;

            // Aim Type dropdown
            OSDropdown *typeDropdown = [[OSDropdown alloc] initWithLabel:@"Aim Type" options:@[@"Aim Lock", @"Silent Aim", @"Triggerbot"] selected:state.aimType];
            typeDropdown.frame = CGRectMake(16, y, 308, 50);
            typeDropdown.onChange = ^(NSString *value) { state.aimType = value; };
            [_contentView addSubview:typeDropdown];
            y += 56;

            // Aim Bone dropdown
            OSDropdown *boneDropdown = [[OSDropdown alloc] initWithLabel:@"Aim Bone" options:@[@"Body", @"Head", @"Neck", @"Chest"] selected:state.aimBone];
            boneDropdown.frame = CGRectMake(16, y, 308, 50);
            boneDropdown.onChange = ^(NSString *value) { state.aimBone = value; };
            [_contentView addSubview:boneDropdown];
            y += 56;

            // FOV Slider
            OSSliderView *fovSlider = [[OSSliderView alloc] initWithLabel:@"Aimbot FOV" value:state.aimFOV min:1 max:360];
            fovSlider.frame = CGRectMake(16, y, 308, 60);
            fovSlider.onChange = ^(double value) { state.aimFOV = value; };
            [_contentView addSubview:fovSlider];
            y += 66;

            // Smoothness Slider
            OSSliderView *smoothSlider = [[OSSliderView alloc] initWithLabel:@"Smoothness" value:state.aimSmooth min:0 max:100];
            smoothSlider.frame = CGRectMake(16, y, 308, 60);
            smoothSlider.onChange = ^(double value) { state.aimSmooth = value; };
            [_contentView addSubview:smoothSlider];
            y += 66;

            OSToggle *visToggle = [[OSToggle alloc] initWithLabel:@"Visibility Check" state:state.visibilityCheck];
            visToggle.frame = CGRectMake(16, y, 308, 44);
            visToggle.onToggle = ^(BOOL isOn) { state.visibilityCheck = isOn; };
            [_contentView addSubview:visToggle];
            y += 50;

        } else { // Advanced
            OSToggle *advToggle = [[OSToggle alloc] initWithLabel:@"Aimbot Advanced" state:state.aimAdvanced];
            advToggle.frame = CGRectMake(16, y, 308, 44);
            advToggle.onToggle = ^(BOOL isOn) { state.aimAdvanced = isOn; };
            [_contentView addSubview:advToggle];
            y += 50;

            OSSliderView *radiusSlider = [[OSSliderView alloc] initWithLabel:@"Aimbot Radius" value:state.aimRadius min:0 max:5000];
            radiusSlider.frame = CGRectMake(16, y, 308, 60);
            radiusSlider.onChange = ^(double value) { state.aimRadius = value; };
            [_contentView addSubview:radiusSlider];
            y += 66;
        }
    }

    // ====== PLAYER TAB ======
    else if ([_currentTab isEqualToString:@"Player"]) {
        NSArray *subTabs = @[@"General", @"Advanced", @"Skin"];
        [self setupSubTabs:subTabs y:0];
        y = 50;

        if ([_currentSubTab isEqualToString:@"General"]) {
            OSToggle *crossToggle = [[OSToggle alloc] initWithLabel:@"Crosshair" state:state.crosshair];
            crossToggle.frame = CGRectMake(16, y, 308, 44);
            crossToggle.onToggle = ^(BOOL isOn) { state.crosshair = isOn; [self showToast:[NSString stringWithFormat:@"Crosshair: %@", isOn ? @"ON ✓" : @"OFF"]]; };
            [_contentView addSubview:crossToggle];
            y += 50;

            OSToggle *stamToggle = [[OSToggle alloc] initWithLabel:@"Unlimited Stamina" state:state.unlimitedStamina];
            stamToggle.frame = CGRectMake(16, y, 308, 44);
            stamToggle.onToggle = ^(BOOL isOn) { state.unlimitedStamina = isOn; [self showToast:isOn ? @"✓ Stamina: ∞ Unlimited" : @"Stamina: Normal"]; };
            [_contentView addSubview:stamToggle];
            y += 50;

            OSToggle *modToggle = [[OSToggle alloc] initWithLabel:@"Player Modification" state:state.playerMod];
            modToggle.frame = CGRectMake(16, y, 308, 44);
            modToggle.onToggle = ^(BOOL isOn) { state.playerMod = isOn; };
            [_contentView addSubview:modToggle];
            y += 50;

        } else if ([_currentSubTab isEqualToString:@"Advanced"]) {
            OSToggle *fovToggle = [[OSToggle alloc] initWithLabel:@"FOV Changer" state:state.fovChanger];
            fovToggle.frame = CGRectMake(16, y, 308, 44);
            fovToggle.onToggle = ^(BOOL isOn) { state.fovChanger = isOn; };
            [_contentView addSubview:fovToggle];
            y += 50;

            if (state.fovChanger) {
                OSSliderView *fovSlider = [[OSSliderView alloc] initWithLabel:@"FOV" value:state.fovValue min:60 max:120];
                fovSlider.frame = CGRectMake(16, y, 308, 60);
                fovSlider.onChange = ^(double value) { state.fovValue = value; };
                [_contentView addSubview:fovSlider];
                y += 66;
            }

            OSToggle *speedToggle = [[OSToggle alloc] initWithLabel:@"Speed Hack" state:state.speedHack];
            speedToggle.frame = CGRectMake(16, y, 308, 44);
            speedToggle.onToggle = ^(BOOL isOn) { state.speedHack = isOn; };
            [_contentView addSubview:speedToggle];
            y += 50;

            if (state.speedHack) {
                OSSliderView *speedSlider = [[OSSliderView alloc] initWithLabel:@"Speed" value:state.speedValue min:1 max:10];
                speedSlider.frame = CGRectMake(16, y, 308, 60);
                speedSlider.onChange = ^(double value) { state.speedValue = value; };
                [_contentView addSubview:speedSlider];
                y += 66;
            }

            OSToggle *vehToggle = [[OSToggle alloc] initWithLabel:@"Vehicle Speed" state:state.vehicleSpeed];
            vehToggle.frame = CGRectMake(16, y, 308, 44);
            vehToggle.onToggle = ^(BOOL isOn) { state.vehicleSpeed = isOn; };
            [_contentView addSubview:vehToggle];
            y += 50;

            OSToggle *flyToggle = [[OSToggle alloc] initWithLabel:@"Fly Hack" state:state.flyHack];
            flyToggle.frame = CGRectMake(16, y, 308, 44);
            flyToggle.onToggle = ^(BOOL isOn) { state.flyHack = isOn; [self showToast:isOn ? @"✈ Fly Hack ENABLED" : @"Fly Hack OFF"]; };
            [_contentView addSubview:flyToggle];
            y += 50;

        } else { // Skin
            OSDropdown *skinDropdown = [[OSDropdown alloc] initWithLabel:@"Choose Skin" options:@[@"ManJohn", @"WomanJohn", @"Custom", @"NPC_Police", @"NPC_Guard"] selected:state.selectedSkin];
            skinDropdown.frame = CGRectMake(16, y, 308, 50);
            skinDropdown.onChange = ^(NSString *value) { state.selectedSkin = value; };
            [_contentView addSubview:skinDropdown];
            y += 56;

            OSDropdown *clothesDropdown = [[OSDropdown alloc] initWithLabel:@"Choose Clothes" options:@[@"ManJohn", @"Suit", @"Casual", @"Military", @"Police"] selected:state.selectedClothes];
            clothesDropdown.frame = CGRectMake(16, y, 308, 50);
            clothesDropdown.onChange = ^(NSString *value) { state.selectedClothes = value; };
            [_contentView addSubview:clothesDropdown];
            y += 56;

            UIButton *applyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            applyBtn.frame = CGRectMake(16, y, 308, 44);
            [applyBtn setTitle:@"Apply Skin" forState:UIControlStateNormal];
            applyBtn.backgroundColor = OS_BG_BTN;
            applyBtn.layer.cornerRadius = 8;
            applyBtn.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
            [applyBtn addTarget:self action:@selector(applySkin) forControlEvents:UIControlEventTouchUpInside];
            [_contentView addSubview:applyBtn];
            y += 56;
        }
    }

    // ====== TELEPORT TAB ======
    else if ([_currentTab isEqualToString:@"Teleport"]) {
        NSArray *subTabs = @[@"Navigation", @"Graffiti", @"Job"];
        [self setupSubTabs:subTabs y:0];
        y = 50;

        if ([_currentSubTab isEqualToString:@"Navigation"]) {
            UIButton *mainTeleport = [UIButton buttonWithType:UIButtonTypeCustom];
            mainTeleport.frame = CGRectMake(16, y, 308, 50);
            [mainTeleport setTitle:@"📍 Teleport to NavMarker" forState:UIControlStateNormal];
            mainTeleport.backgroundColor = OS_BG_BTN;
            mainTeleport.layer.cornerRadius = 10;
            [mainTeleport addTarget:self action:@selector(teleportToNavMarker) forControlEvents:UIControlEventTouchUpInside];
            [_contentView addSubview:mainTeleport];
            y += 60;

            NSArray *markers = @[@"NavMarker", @"NavMarker 2", @"NavMarker 3", @"NavMarker 4", @"NavMarker 5"];
            for (NSString *marker in markers) {
                UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                btn.frame = CGRectMake(16, y, 308, 44);
                [btn setTitle:marker forState:UIControlStateNormal];
                [btn setTitleColor:OS_TEXT1 forState:UIControlStateNormal];
                btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                btn.titleEdgeInsets = UIEdgeInsetsMake(0, 12, 0, 0);
                btn.backgroundColor = [UIColor clearColor];
                [btn addTarget:self action:@selector(teleportTo:) forControlEvents:UIControlEventTouchUpInside];
                objc_setAssociatedObject(btn, "marker", marker, OBJC_ASSOCIATION_RETAIN);
                [_contentView addSubview:btn];

                UIView *line = [[UIView alloc] initWithFrame:CGRectMake(16, y + 43, 292, 1)];
                line.backgroundColor = OS_BORDER;
                [_contentView addSubview:line];

                y += 44;
            }

        } else {
            UILabel *empty = [[UILabel alloc] initWithFrame:CGRectMake(16, y + 40, 308, 30)];
            empty.text = [_currentSubTab isEqualToString:@"Graffiti"] ? @"No active checkpoints found." : @"No active jobs found.";
            empty.textColor = OS_TEXT3;
            empty.textAlignment = NSTextAlignmentCenter;
            empty.font = [UIFont systemFontOfSize:14];
            [_contentView addSubview:empty];
            y += 80;
        }
    }

    // ====== SETTINGS TAB ======
    else if ([_currentTab isEqualToString:@"Settings"]) {
        // Streamer Mode
        OSToggle *streamToggle = [[OSToggle alloc] initWithLabel:@"Streamer Mode" state:state.streamerMode];
        streamToggle.frame = CGRectMake(16, y, 308, 44);
        streamToggle.onToggle = ^(BOOL isOn) {
            state.streamerMode = isOn;
            [self showToast:[NSString stringWithFormat:@"Streamer Mode: %@", isOn ? @"ON" : @"OFF"]];
            [self refreshContent]; // Refresh to hide/show info
        };
        [_contentView addSubview:streamToggle];
        y += 50;

        // Deactivate Cheat
        OSToggle *deactToggle = [[OSToggle alloc] initWithLabel:@"Deactivate Cheat" state:state.deactivateCheat];
        deactToggle.frame = CGRectMake(16, y, 308, 44);
        deactToggle.onToggle = ^(BOOL isOn) {
            state.deactivateCheat = isOn;
            if (isOn) [state deactivateAll];
            [self showToast:isOn ? @"⚠ Cheat Deactivated" : @"✓ Cheat Activated"];
        };
        [_contentView addSubview:deactToggle];
        y += 50;

        // Target FPS
        OSSliderView *fpsSlider = [[OSSliderView alloc] initWithLabel:@"Target FPS" value:state.targetFPS min:10 max:240];
        fpsSlider.frame = CGRectMake(16, y, 308, 60);
        fpsSlider.onChange = ^(double value) { state.targetFPS = value; };
        [_contentView addSubview:fpsSlider];
        y += 66;

        // Frame Delay info
        UILabel *delayLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, y, 308, 20)];
        delayLabel.text = [NSString stringWithFormat:@"Frame Delay: %d ms", (int)(1000.0 / state.targetFPS)];
        delayLabel.font = [UIFont systemFontOfSize:12];
        delayLabel.textColor = OS_TEXT3;
        [_contentView addSubview:delayLabel];
        y += 30;

        // Save button
        UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        saveBtn.frame = CGRectMake(16, y, 308, 44);
        [saveBtn setTitle:@"💾 Save Settings" forState:UIControlStateNormal];
        saveBtn.backgroundColor = OS_BG_BTN;
        saveBtn.layer.cornerRadius = 10;
        [saveBtn addTarget:self action:@selector(saveSettings) forControlEvents:UIControlEventTouchUpInside];
        [_contentView addSubview:saveBtn];
        y += 56;

        // State Summary
        UIView *summary = [[UIView alloc] initWithFrame:CGRectMake(16, y, 308, 200)];
        summary.backgroundColor = OS_BG_ITEM;
        summary.layer.cornerRadius = 10;

        UILabel *sumTitle = [[UILabel alloc] initWithFrame:CGRectMake(12, 10, 284, 16)];
        sumTitle.text = @"CURRENT STATE";
        sumTitle.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
        sumTitle.textColor = OS_TEXT3;
        sumTitle.letterSpacing = 1;
        [summary addSubview:sumTitle];

        NSArray *states = @[@
            @{@"label": @"ESP", @"on": @(state.espEnabled)},
            @{@"label": @"Aimbot", @"on": @(state.aimbotEnabled)},
            @{@"label": @"Crosshair", @"on": @(state.crosshair)},
            @{@"label": @"Stamina ∞", @"on": @(state.unlimitedStamina)},
            @{@"label": @"Fly Hack", @"on": @(state.flyHack)},
            @{@"label": @"Speed Hack", @"on": @(state.speedHack)},
            @{@"label": @"Streamer", @"on": @(state.streamerMode)}
        ];

        CGFloat sy = 32;
        for (NSDictionary *item in states) {
            UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(12, sy + 4, 6, 6)];
            dot.backgroundColor = [item[@"on"] boolValue] ? OS_GREEN : OS_RED;
            dot.layer.cornerRadius = 3;
            [summary addSubview:dot];

            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(24, sy, 100, 16)];
            lbl.text = [NSString stringWithFormat:@"%@: ", item[@"label"]];
            lbl.font = [UIFont systemFontOfSize:12];
            lbl.textColor = OS_TEXT2;
            [summary addSubview:lbl];

            UILabel *val = [[UILabel alloc] initWithFrame:CGRectMake(120, sy, 50, 16)];
            val.text = [item[@"on"] boolValue] ? @"ON" : @"OFF";
            val.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
            val.textColor = [item[@"on"] boolValue] ? OS_GREEN : OS_RED;
            [summary addSubview:val];

            sy += 20;
        }

        // Target FPS
        UIView *fpsDot = [[UIView alloc] initWithFrame:CGRectMake(12, sy + 4, 6, 6)];
        fpsDot.backgroundColor = OS_PURPLE;
        fpsDot.layer.cornerRadius = 3;
        [summary addSubview:fpsDot];

        UILabel *fpsLbl = [[UILabel alloc] initWithFrame:CGRectMake(24, sy, 100, 16)];
        fpsLbl.text = @"Target FPS: ";
        fpsLbl.font = [UIFont systemFontOfSize:12];
        fpsLbl.textColor = OS_TEXT2;
        [summary addSubview:fpsLbl];

        UILabel *fpsVal = [[UILabel alloc] initWithFrame:CGRectMake(120, sy, 80, 16)];
        fpsVal.text = [NSString stringWithFormat:@"%.0f fps", state.targetFPS];
        fpsVal.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
        fpsVal.textColor = OS_PURPLE;
        [summary addSubview:fpsVal];

        [_contentView addSubview:summary];
        y += 210;
    }

    _contentView.frame = CGRectMake(0, 0, 340, y + 20);
    _scrollView.contentSize = CGSizeMake(340, y + 20);
}

- (void)setupSubTabs:(NSArray *)tabs y:(CGFloat)y {
    UIView *subTabBar = [_menuContainer viewWithTag:200];

    CGFloat tabWidth = 340.0 / tabs.count;
    for (int i = 0; i < tabs.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(i * tabWidth + 4, 4, tabWidth - 8, 28);
        [btn setTitle:tabs[i] forState:UIControlStateNormal];
        [btn setTitleColor:OS_TEXT3 forState:UIControlStateNormal];
        [btn setTitleColor:OS_TEXT1 forState:UIControlStateSelected];
        btn.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
        btn.layer.cornerRadius = 6;
        btn.tag = i;

        if ([tabs[i] isEqualToString:_currentSubTab]) {
            btn.selected = YES;
            btn.backgroundColor = OS_BG_BTN;
        }

        [btn addTarget:self action:@selector(subTabTapped:) forControlEvents:UIControlEventTouchUpInside];
        objc_setAssociatedObject(btn, "tabName", tabs[i], OBJC_ASSOCIATION_COPY);
        [subTabBar addSubview:btn];
    }
}

- (void)subTabTapped:(UIButton *)sender {
    NSString *tabName = objc_getAssociatedObject(sender, "tabName");
    [self switchToSubTab:tabName];
}

- (void)showMenu {
    self.hidden = NO;
    _menuContainer.transform = CGAffineTransformMakeScale(0.85, 0.85);
    _menuContainer.alpha = 0;

    [UIView animateWithDuration:0.25 delay:0 usingSpringWithDamping:0.8 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseOut animations:^{
        _menuContainer.transform = CGAffineTransformIdentity;
        _menuContainer.alpha = 1;
    } completion:nil];
}

- (void)hideMenu {
    [UIView animateWithDuration:0.2 animations:^{
        _menuContainer.transform = CGAffineTransformMakeScale(0.85, 0.85);
        _menuContainer.alpha = 0;
    } completion:^(BOOL finished) {
        self.hidden = YES;
    }];
}

- (void)handlePan:(UIPanGestureRecognizer *)gesture {
    CGPoint translation = [gesture translationInView:self];
    CGPoint newCenter = CGPointMake(_menuContainer.center.x + translation.x, _menuContainer.center.y + translation.y);

    // Keep within bounds
    CGFloat halfW = _menuContainer.bounds.size.width / 2;
    CGFloat halfH = _menuContainer.bounds.size.height / 2;
    newCenter.x = MAX(halfW, MIN(self.bounds.size.width - halfW, newCenter.x));
    newCenter.y = MAX(halfH, MIN(self.bounds.size.height - halfH, newCenter.y));

    _menuContainer.center = newCenter;
    [gesture setTranslation:CGPointZero inView:self];
}

- (void)showToast:(NSString *)message {
    UILabel *toast = [[UILabel alloc] init];
    toast.text = message;
    toast.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    toast.textColor = [UIColor whiteColor];
    toast.backgroundColor = OS_PURPLE;
    toast.textAlignment = NSTextAlignmentCenter;
    toast.layer.cornerRadius = 10;
    toast.clipsToBounds = YES;
    [toast sizeToFit];
    toast.frame = CGRectMake(0, 0, toast.frame.size.width + 40, 36);
    toast.center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height - 100);

    [self addSubview:toast];

    toast.transform = CGAffineTransformMakeTranslation(0, 50);
    toast.alpha = 0;

    [UIView animateWithDuration:0.3 animations:^{
        toast.transform = CGAffineTransformIdentity;
        toast.alpha = 1;
    }];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.3 animations:^{
            toast.transform = CGAffineTransformMakeTranslation(0, 50);
            toast.alpha = 0;
        } completion:^(BOOL finished) {
            [toast removeFromSuperview];
        }];
    });
}

- (void)applySkin {
    OSAppState *state = [OSAppState sharedState];
    [self showToast:[NSString stringWithFormat:@"🎭 Skin: %@ | Clothes: %@", state.selectedSkin, state.selectedClothes]];
}

- (void)teleportToNavMarker {
    [self showToast:@"📍 Teleported to NavMarker"];
}

- (void)teleportTo:(UIButton *)sender {
    NSString *marker = objc_getAssociatedObject(sender, "marker");
    [self showToast:[NSString stringWithFormat:@"📍 Teleported to %@", marker]];
}

- (void)saveSettings {
    [self showToast:@"✓ Settings saved successfully"];
}

@end

// ====== UI COMPONENTS IMPLEMENTATION ======

@implementation OSToggle

- (instancetype)initWithLabel:(NSString *)label state:(BOOL)state {
    self = [super init];
    if (self) {
        _label = [[UILabel alloc] init];
        _label.text = label;
        _label.font = [UIFont systemFontOfSize:16];
        _label.textColor = OS_TEXT1;

        _toggle = [[UISwitch alloc] init];
        _toggle.on = state;
        _toggle.onTintColor = OS_PURPLE;
        [_toggle addTarget:self action:@selector(toggled:) forControlEvents:UIControlEventValueChanged];

        [self addSubview:_label];
        [self addSubview:_toggle];

        _label.frame = CGRectMake(0, 0, 200, 44);
        _toggle.frame = CGRectMake(250, 6, 51, 31);
    }
    return self;
}

- (void)toggled:(UISwitch *)sender {
    if (_onToggle) _onToggle(sender.isOn);
}

@end

@implementation OSSliderView

- (instancetype)initWithLabel:(NSString *)label value:(double)value min:(double)min max:(double)max {
    self = [super init];
    if (self) {
        _label = [[UILabel alloc] init];
        _label.text = label;
        _label.font = [UIFont systemFontOfSize:14];
        _label.textColor = OS_TEXT2;

        _valueLabel = [[UILabel alloc] init];
        _valueLabel.text = [NSString stringWithFormat:@"%.0f", value];
        _valueLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        _valueLabel.textColor = OS_PURPLE;
        _valueLabel.textAlignment = NSTextAlignmentRight;

        _slider = [[UISlider alloc] init];
        _slider.minimumValue = min;
        _slider.maximumValue = max;
        _slider.value = value;
        _slider.minimumTrackTintColor = OS_PURPLE;
        _slider.maximumTrackTintColor = OS_BG_ITEM;
        [_slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];

        [self addSubview:_label];
        [self addSubview:_valueLabel];
        [self addSubview:_slider];

        _label.frame = CGRectMake(0, 0, 200, 20);
        _valueLabel.frame = CGRectMake(240, 0, 60, 20);
        _slider.frame = CGRectMake(0, 24, 300, 30);
    }
    return self;
}

- (void)sliderChanged:(UISlider *)sender {
    _valueLabel.text = [NSString stringWithFormat:@"%.0f", sender.value];
    if (_onChange) _onChange(sender.value);
}

@end

@implementation OSCheckbox

- (instancetype)initWithLabel:(NSString *)label checked:(BOOL)checked {
    self = [super init];
    if (self) {
        _isChecked = checked;

        _box = [[UIView alloc] initWithFrame:CGRectMake(0, 9, 22, 22)];
        _box.backgroundColor = checked ? OS_PURPLE : OS_BG_ITEM;
        _box.layer.cornerRadius = 5;
        _box.layer.borderWidth = 1;
        _box.layer.borderColor = checked ? OS_PURPLE.CGColor : OS_BORDER.CGColor;

        if (checked) {
            UILabel *check = [[UILabel alloc] initWithFrame:_box.bounds];
            check.text = @"✓";
            check.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
            check.textColor = [UIColor whiteColor];
            check.textAlignment = NSTextAlignmentCenter;
            [_box addSubview:check];
        }

        _label = [[UILabel alloc] initWithFrame:CGRectMake(34, 0, 200, 40)];
        _label.text = label;
        _label.font = [UIFont systemFontOfSize:16];
        _label.textColor = OS_TEXT1;

        [self addSubview:_box];
        [self addSubview:_label];

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped)];
        [self addGestureRecognizer:tap];
    }
    return self;
}

- (void)tapped {
    _isChecked = !_isChecked;
    _box.backgroundColor = _isChecked ? OS_PURPLE : OS_BG_ITEM;
    _box.layer.borderColor = _isChecked ? OS_PURPLE.CGColor : OS_BORDER.CGColor;

    if (_isChecked) {
        UILabel *check = [[UILabel alloc] initWithFrame:_box.bounds];
        check.text = @"✓";
        check.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
        check.textColor = [UIColor whiteColor];
        check.textAlignment = NSTextAlignmentCenter;
        check.tag = 1;
        [_box addSubview:check];
    } else {
        [[_box viewWithTag:1] removeFromSuperview];
    }

    if (_onToggle) _onToggle(_isChecked);
}

@end

@implementation OSDropdown

- (instancetype)initWithLabel:(NSString *)label options:(NSArray *)options selected:(NSString *)selected {
    self = [super init];
    if (self) {
        _options = options;
        _selected = selected;

        _label = [[UILabel alloc] init];
        _label.text = label;
        _label.font = [UIFont systemFontOfSize:14];
        _label.textColor = OS_TEXT2;

        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        [_button setTitle:selected forState:UIControlStateNormal];
        [_button setTitleColor:OS_TEXT1 forState:UIControlStateNormal];
        _button.backgroundColor = OS_BG_ITEM;
        _button.layer.cornerRadius = 8;
        _button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _button.titleEdgeInsets = UIEdgeInsetsMake(0, 12, 0, 0);
        _button.titleLabel.font = [UIFont systemFontOfSize:15];
        [_button addTarget:self action:@selector(showOptions) forControlEvents:UIControlEventTouchUpInside];

        UIImageView *arrow = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"chevron.down"]];
        arrow.tintColor = OS_PURPLE;
        arrow.frame = CGRectMake(270, 14, 16, 16);
        [_button addSubview:arrow];

        [self addSubview:_label];
        [self addSubview:_button];

        _label.frame = CGRectMake(0, 0, 200, 20);
        _button.frame = CGRectMake(0, 22, 300, 44);
    }
    return self;
}

- (void)showOptions {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:_label.text message:nil preferredStyle:UIAlertControllerStyleActionSheet];

    for (NSString *option in _options) {
        UIAlertAction *action = [UIAlertAction actionWithTitle:option style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            self.selected = option;
            [self.button setTitle:option forState:UIControlStateNormal];
            if (self.onChange) self.onChange(option);
        }];
        [alert addAction:action];
    }

    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:cancel];

    UIViewController *root = [UIApplication sharedApplication].keyWindow.rootViewController;
    [root presentViewController:alert animated:YES completion:nil];
}

@end

@implementation OSStatusBadge

- (instancetype)initWithActive:(BOOL)active activeText:(NSString *)activeText inactiveText:(NSString *)inactiveText {
    self = [super init];
    if (self) {
        self.backgroundColor = (active ? OS_GREEN : OS_RED).alphaComponent(0.12);
        self.layer.cornerRadius = 8;
        self.layer.borderWidth = 1;
        self.layer.borderColor = (active ? OS_GREEN : OS_RED).alphaComponent(0.3).CGColor;

        _dot = [[UIView alloc] initWithFrame:CGRectMake(10, 11, 7, 7)];
        _dot.backgroundColor = active ? OS_GREEN : OS_RED;
        _dot.layer.cornerRadius = 3.5;
        [self addSubview:_dot];

        _label = [[UILabel alloc] initWithFrame:CGRectMake(24, 0, 110, 30)];
        _label.text = active ? activeText : inactiveText;
        _label.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
        _label.textColor = active ? OS_GREEN : OS_RED;
        [self addSubview:_label];
    }
    return self;
}

- (void)setActive:(BOOL)active {
    self.backgroundColor = (active ? OS_GREEN : OS_RED).alphaComponent(0.12);
    self.layer.borderColor = (active ? OS_GREEN : OS_RED).alphaComponent(0.3).CGColor;
    _dot.backgroundColor = active ? OS_GREEN : OS_RED;
    _label.textColor = active ? OS_GREEN : OS_RED;
}

@end

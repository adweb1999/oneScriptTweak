//
//  Utils.h
//  oneScriptTweak - Utility Functions
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface OSUtils : NSObject

// Memory utilities
+ (void)writeMemory:(uintptr_t)address value:(uint32_t)value;
+ (uint32_t)readMemory:(uintptr_t)address;
+ (void)writeFloat:(uintptr_t)address value:(float)value;
+ (float)readFloat:(uintptr_t)address;
+ (void)writeBytes:(uintptr_t)address bytes:(const void *)bytes length:(size_t)length;

// Hook utilities
+ (void)hookFunction:(void *)target with:(void *)replacement original:(void **)original;
+ (void)hookMessage:(Class)cls selector:(SEL)sel imp:(IMP)imp;

// Math utilities
+ (float)distanceFrom:(CGPoint)a to:(CGPoint)b;
+ (float)angleFrom:(CGPoint)a to:(CGPoint)b;
+ (CGPoint)lerpFrom:(CGPoint)a to:(CGPoint)b factor:(float)t;

// Drawing utilities
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;
+ (void)addGlowToView:(UIView *)view color:(UIColor *)color radius:(CGFloat)radius;

// Device info
+ (NSString *)deviceModel;
+ (NSString *)iosVersion;
+ (BOOL)isJailbroken;
+ (BOOL)isDebuggerAttached;

@end

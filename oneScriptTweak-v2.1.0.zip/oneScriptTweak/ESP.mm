//
//  ESP.mm
//  oneScriptTweak - ESP Implementation
//

#import "ESP.h"
#import "MenuView.h"
#import <QuartzCore/QuartzCore.h>

@implementation OSESPEngine

+ (instancetype)sharedEngine {
    static OSESPEngine *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _enabled = NO;
        _showBoxes = YES;
        _showSnaplines = YES;
        _showSkeleton = NO;
        _showNames = YES;
        _showDistance = YES;
        _showHealth = YES;
        _maxDistance = 500.0f;

        _enemyColor = [UIColor colorWithRed:0.937 green:0.267 blue:0.267 alpha:1.0];  // Red
        _teamColor = [UIColor colorWithRed:0.290 green:0.871 blue:0.502 alpha:1.0];   // Green
        _npcColor = [UIColor colorWithRed:0.961 green:0.651 blue:0.137 alpha:1.0];     // Orange
        _vehicleColor = [UIColor colorWithRed:0.486 green:0.416 blue:0.961 alpha:1.0]; // Purple
    }
    return self;
}

- (void)drawESPOnView:(UIView *)gameView {
    if (!_enabled) return;

    // Remove old ESP layer
    [[gameView viewWithTag:0xESP] removeFromSuperview];

    UIView *espLayer = [[UIView alloc] initWithFrame:gameView.bounds];
    espLayer.tag = 0xESP;
    espLayer.userInteractionEnabled = NO;
    espLayer.backgroundColor = [UIColor clearColor];

    NSArray *entities = [self getEntities];
    for (NSDictionary *entity in entities) {
        CGPoint screenPos = [self worldToScreen:[entity[@"pos"] CGVectorValue] view:gameView];
        if (screenPos.x < 0 || screenPos.y < 0) continue;

        float distance = [entity[@"distance"] floatValue];
        if (distance > _maxDistance) continue;

        UIColor *color = [entity[@"team"] boolValue] ? _teamColor : _enemyColor;
        NSString *type = entity[@"type"];

        if ([type isEqualToString:@"vehicle"]) color = _vehicleColor;
        else if ([type isEqualToString:@"npc"]) color = _npcColor;

        float boxSize = MAX(30, 200 - distance * 0.3);
        CGRect box = CGRectMake(screenPos.x - boxSize/2, screenPos.y - boxSize, boxSize, boxSize * 1.5);

        if (_showBoxes) {
            [self drawBox:box color:color view:espLayer];
        }

        if (_showSnaplines) {
            CGPoint screenCenter = CGPointMake(gameView.bounds.size.width / 2, gameView.bounds.size.height);
            [self drawSnapline:screenCenter to:CGPointMake(screenPos.x, screenPos.y + boxSize/2) color:color view:espLayer];
        }

        if (_showNames) {
            NSString *name = entity[@"name"];
            [self drawText:name at:CGPointMake(screenPos.x, screenPos.y - boxSize - 20) color:color view:espLayer];
        }

        if (_showDistance) {
            NSString *distText = [NSString stringWithFormat:@"%.0fm", distance];
            [self drawText:distText at:CGPointMake(screenPos.x, screenPos.y + boxSize/2 + 5) color:OS_TEXT2 view:espLayer];
        }

        if (_showHealth) {
            float health = [entity[@"health"] floatValue];
            float maxHealth = [entity[@"maxHealth"] floatValue];
            [self drawHealthBar:screenPos health:health maxHealth:maxHealth boxHeight:boxSize * 1.5 view:espLayer];
        }
    }

    [gameView addSubview:espLayer];
}

- (void)drawBox:(CGRect)rect color:(UIColor *)color view:(UIView *)view {
    UIView *box = [[UIView alloc] initWithFrame:rect];
    box.backgroundColor = [UIColor clearColor];
    box.layer.borderWidth = 1.5;
    box.layer.borderColor = color.CGColor;
    box.layer.cornerRadius = 2;
    [view addSubview:box];
}

- (void)drawSnapline:(CGPoint)from to:(CGPoint)to color:(UIColor *)color view:(UIView *)view {
    CAShapeLayer *line = [CAShapeLayer layer];
    line.strokeColor = color.CGColor;
    line.lineWidth = 1.0;
    line.opacity = 0.6;

    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:from];
    [path addLineToPoint:to];
    line.path = path.CGPath;

    [view.layer addSublayer:line];
}

- (void)drawSkeleton:(NSArray *)bones color:(UIColor *)color view:(UIView *)view {
    for (int i = 0; i < bones.count - 1; i++) {
        CGPoint from = [bones[i] CGPointValue];
        CGPoint to = [bones[i+1] CGPointValue];
        [self drawSnapline:from to:to color:color view:view];
    }
}

- (void)drawText:(NSString *)text at:(CGPoint)point color:(UIColor *)color view:(UIView *)view {
    UILabel *label = [[UILabel alloc] init];
    label.text = text;
    label.font = [UIFont systemFontOfSize:10 weight:UIFontWeightMedium];
    label.textColor = color;
    label.textAlignment = NSTextAlignmentCenter;
    [label sizeToFit];
    label.center = point;
    label.shadowColor = [UIColor blackColor];
    label.shadowOffset = CGSizeMake(1, 1);
    [view addSubview:label];
}

- (void)drawHealthBar:(CGPoint)center health:(float)health maxHealth:(float)maxHealth boxHeight:(float)boxHeight view:(UIView *)view {
    float barWidth = 4;
    float barHeight = boxHeight;
    float healthPct = health / maxHealth;

    UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(center.x - 50, center.y - barHeight/2, barWidth, barHeight)];
    bg.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.8];
    bg.layer.cornerRadius = 2;
    [view addSubview:bg];

    UIColor *healthColor = healthPct > 0.6 ? OS_GREEN : (healthPct > 0.3 ? OS_ORANGE : OS_RED);
    UIView *fill = [[UIView alloc] initWithFrame:CGRectMake(bg.frame.origin.x, bg.frame.origin.y + barHeight * (1 - healthPct), barWidth, barHeight * healthPct)];
    fill.backgroundColor = healthColor;
    fill.layer.cornerRadius = 2;
    [view addSubview:fill];
}

- (NSArray *)getEntities {
    // OVERRIDE THIS METHOD FOR YOUR SPECIFIC GAME
    // Return array of dictionaries with keys: @"pos", @"name", @"distance", @"health", @"maxHealth", @"team", @"type"

    // Example dummy data:
    return @[
        @{@"pos": [NSValue valueWithCGVector:CGVectorMake(100, 50, 200)], 
          @"name": @"Player1", @"distance": @(150.0f), @"health": @(80.0f), 
          @"maxHealth": @(100.0f), @"team": @(NO), @"type": @"player"},
        @{@"pos": [NSValue valueWithCGVector:CGVectorMake(-50, 30, 100)], 
          @"name": @"Player2", @"distance": @(75.0f), @"health": @(45.0f), 
          @"maxHealth": @(100.0f), @"team": @(YES), @"type": @"player"}
    ];
}

- (CGPoint)worldToScreen:(CGVector)worldPos view:(UIView *)view {
    // OVERRIDE THIS METHOD FOR YOUR SPECIFIC GAME
    // Implement your game's world-to-screen transformation

    // Simple projection example:
    float screenX = view.bounds.size.width / 2 + worldPos.dx * 2;
    float screenY = view.bounds.size.height / 2 - worldPos.dy * 2;
    return CGPointMake(screenX, screenY);
}

@end

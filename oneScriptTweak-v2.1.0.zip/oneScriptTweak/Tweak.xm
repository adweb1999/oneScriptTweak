//
//  oneScriptTweak - Main Entry Point
//  Version: 2.1.0
//  Professional Game Enhancement Suite
//

#import <UIKit/UIKit.h>
#import <substrate.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

// ====== IMPORT MODULES ======
#import "MenuView.h"
#import "ESP.h"
#import "Aimbot.h"
#import "Utils.h"

// ====== GLOBAL STATE ======
static OSMenuView *gMenuView = nil;
static UIWindow *gKeyWindow = nil;
static BOOL gMenuVisible = NO;

// ====== CONFIGURATION ======
static NSString * const kBundleFilter = @"com.yourgame.bundle"; // <-- CHANGE THIS TO TARGET GAME

// ====== MENU TRIGGER ======
// Triple-finger double-tap to show menu
%hook UIWindow

- (void)layoutSubviews {
    %orig;

    if (!gMenuView) {
        gMenuView = [[OSMenuView alloc] initWithFrame:self.bounds];
        gMenuView.hidden = YES;
        [self addSubview:gMenuView];

        // Menu trigger: 3-finger double tap
        UITapGestureRecognizer *menuGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleOneScriptMenu)];
        menuGesture.numberOfTapsRequired = 2;
        menuGesture.numberOfTouchesRequired = 3;
        [self addGestureRecognizer:menuGesture];

        // Pan gesture for menu drag
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:gMenuView action:@selector(handlePan:)];
        [gMenuView.menuContainer addGestureRecognizer:panGesture];

        NSLog(@"[oneScript] Menu initialized successfully");
    }
}

%new
- (void)toggleOneScriptMenu {
    if (!gMenuView) return;

    if (gMenuVisible) {
        [gMenuView hideMenu];
        gMenuVisible = NO;
    } else {
        [gMenuView showMenu];
        gMenuVisible = YES;
    }
}

%end

// ====== GAME HOOKS (Example - Modify for your target game) ======
// Hook UIViewController to detect game launch
%hook UIViewController

- (void)viewDidAppear:(BOOL)animated {
    %orig;
    NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
    NSLog(@"[oneScript] View appeared in: %@", bundleID);
}

%end

// ====== CONSTRUCTOR ======
%ctor {
    NSLog(@"========================================");
    NSLog(@"[oneScript] Tweak v2.1.0 Loaded");
    NSLog(@"[oneScript] Build: 2026.06.08");
    NSLog(@"[oneScript] Device: %@", [[UIDevice currentDevice] model]);
    NSLog(@"[oneScript] iOS: %@", [[UIDevice currentDevice] systemVersion]);
    NSLog(@"========================================");

    // Initialize shared state
    [OSAppState sharedState];
}

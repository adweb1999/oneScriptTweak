#!/bin/bash
# oneScript Build Script

echo "========================================"
echo "  oneScript Tweak Builder v2.1.0"
echo "========================================"

# Check Theos
if [ -z "$THEOS" ]; then
    echo "❌ THEOS not set! Please install Theos first."
    echo "   bash -c "\$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)""
    exit 1
fi

echo "✅ Theos found: $THEOS"

# Clean
echo "🧹 Cleaning..."
make clean

# Build
echo "🔨 Building package..."
make package FINALPACKAGE=1

# Check result
if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📦 Package location: packages/"
    ls -la packages/
else
    echo "❌ Build failed!"
    exit 1
fi

echo "========================================"
echo "  Done! Install with: make install"
echo "========================================"

//
//  Aimbot.h
//  oneScriptTweak - Aimbot Module
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface OSAimbotEngine : NSObject

+ (instancetype)sharedEngine;

// Configuration
@property (nonatomic, assign) BOOL enabled;
@property (nonatomic, copy) NSString *aimType;      // "Aim Lock", "Silent Aim", "Triggerbot"
@property (nonatomic, copy) NSString *aimBone;        // "Head", "Body", "Neck", "Chest"
@property (nonatomic, assign) float fov;
@property (nonatomic, assign) float smoothness;
@property (nonatomic, assign) BOOL visibilityCheck;
@property (nonatomic, assign) float maxDistance;
@property (nonatomic, assign) BOOL showFOV;

// Target
@property (nonatomic, weak) id currentTarget;
@property (nonatomic, assign) CGPoint targetScreenPos;

// Methods
- (void)update;
- (id)findBestTarget;
- (BOOL)isVisible:(id)target;
- (CGPoint)getAimPosition:(id)target;
- (void)aimAt:(CGPoint)point;
- (void)drawFOVCircle:(UIView *)view;

@end

# oneScript Tweak v2.1.0

Professional iOS Game Enhancement Suite - Theos Tweak

## 🎮 Features

### Visuals (ESP)
- ✅ ESP Boxes
- ✅ ESP Snaplines
- ✅ ESP Skeleton
- ✅ ESP Names
- ✅ ESP Count
- ✅ ESP Distance
- ✅ Health Bars
- ✅ Advanced ESP Settings
- ✅ Entity Filters (Players, Vehicles, NPCs, Markers)

### Aimbot
- ✅ Aim Lock
- ✅ Silent Aim
- ✅ Triggerbot
- ✅ Custom Aim Bone (Head, Body, Neck, Chest)
- ✅ Adjustable FOV
- ✅ Smoothness Control
- ✅ Visibility Check
- ✅ Advanced Radius Settings

### Player Mods
- ✅ Crosshair Overlay
- ✅ Unlimited Stamina
- ✅ FOV Changer
- ✅ Speed Hack
- ✅ Vehicle Speed Hack
- ✅ Fly Hack
- ✅ Player Modification
- ✅ Skin Changer
- ✅ Clothes Changer

### Teleport
- ✅ Navigation Markers
- ✅ Quick Teleport
- ✅ Custom Locations

### Settings
- ✅ Streamer Mode (hides sensitive info)
- ✅ Deactivate Cheat
- ✅ Target FPS Control
- ✅ Frame Delay Display
- ✅ Save/Load Configuration

## 📁 Project Structure

```
oneScriptTweak/
├── Makefile                          # Build configuration
├── Tweak.xm                          # Main entry point
├── oneScriptTweak.plist              # Filter configuration
├── MenuView.h                        # UI declarations
├── MenuView.mm                       # Full UI implementation
├── ESP.h / ESP.mm                    # ESP engine
├── Aimbot.h / Aimbot.mm              # Aimbot engine
├── Utils.h / Utils.mm                # Utility functions
├── layout/
│   └── DEBIAN/
│       ├── control                   # Package info
│       ├── postinst                  # Post-install script
│       └── prerm                     # Pre-remove script
```

## 🛠️ Requirements

- macOS with Xcode Command Line Tools
- [Theos](https://github.com/theos/theos) installed
- Jailbroken iOS device (iOS 14.0 - 16.5+)
- Target game installed

## 📦 Installation

### 1. Install Theos
```bash
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"
```

### 2. Clone/Copy Project
```bash
cd ~/projects
# Copy the oneScriptTweak folder here
```

### 3. Configure Target Game
Edit `Tweak.xm` and change the bundle identifier:
```objc
static NSString * const kBundleFilter = @"com.yourgame.bundle";
```

### 4. Build
```bash
cd oneScriptTweak
make package
```

### 5. Install on Device
```bash
make install
# Or use SCP to transfer the .deb file
```

## 🎮 How to Use

1. **Launch the game**
2. **Show Menu**: Triple-finger double-tap on screen
3. **Drag Menu**: Pan gesture on menu header
4. **Navigate**: Tap tabs (Visuals, Aimbot, Player, Teleport, Settings)
5. **Toggle Features**: Use switches and checkboxes
6. **Adjust Values**: Use sliders

### Menu Controls
| Gesture | Action |
|---------|--------|
| 3-finger double tap | Show/Hide menu |
| Pan on menu | Drag menu position |
| Tap outside menu | Close menu |

## 🔧 Customization

### Adding Game-Specific Hooks
Edit these files to add your game's specific hooks:

1. **ESP.mm** - `getEntities` and `worldToScreen` methods
2. **Aimbot.mm** - `findBestTarget`, `aimAt`, `sendAimInput` methods
3. **Tweak.xm** - Game class hooks

### Example: Hooking a Game Class
```objc
%hook GamePlayerController

- (void)update {
    %orig;

    OSESPEngine *esp = [OSESPEngine sharedEngine];
    if (esp.enabled) {
        [esp drawESPOnView:self.view];
    }

    OSAimbotEngine *aimbot = [OSAimbotEngine sharedEngine];
    [aimbot update];
}

%end
```

## 🎨 Theme Colors

| Color | Hex | Usage |
|-------|-----|-------|
| Background | `#12111a` | Main background |
| Panel | `#1a1925` | Sidebar/panels |
| Card | `#211f2e` | Cards |
| Purple | `#7c6af5` | Primary accent |
| Green | `#4ade80` | Success/Online |
| Red | `#f87171` | Danger/Offline |
| Orange | `#f5a623` | Warning/Expiry |

## 📝 Changelog

### v2.1.0 (2026.06.08)
- Full UI redesign with glassmorphism
- Added Skin Changer
- Added Teleport system
- Added Streamer Mode
- Performance optimizations
- iOS 16.5 support

## ⚠️ Disclaimer

This tool is for educational purposes only. Use at your own risk. The developers are not responsible for any bans or account suspensions.

## 📄 License

Private - All rights reserved. Unauthorized distribution prohibited.

---
**Built with ❤️ by oneScript Team**
